"""Current version of package validate_version_code"""
__version__ = "1.0.4"